import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Slot Nusantara'),
        backgroundColor: Colors.grey[900],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('Selamat datang di Slot Nusantara!',
                style: TextStyle(color: Colors.white, fontSize: 18)),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {},
              child: Text('Claim Coin Harian'),
            ),
          ],
        ),
      ),
    );
  }
}
