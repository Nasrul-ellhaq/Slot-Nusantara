import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(SlotNusantaraApp());
}

class SlotNusantaraApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Slot Nusantara',
      theme: ThemeData(
        primarySwatch: Colors.grey,
        scaffoldBackgroundColor: Color(0xFF1C1C1E),
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: HomeScreen(),
    );
  }
}
