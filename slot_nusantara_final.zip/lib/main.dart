import 'package:flutter/material.dart';
import 'home_screen.dart';

void main() {
  runApp(SlotNusantaraApp());
}

class SlotNusantaraApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Slot Nusantara',
      theme: ThemeData(
        primarySwatch: Colors.grey,
        fontFamily: 'Arial',
      ),
      home: HomeScreen(),
    );
  }
}
